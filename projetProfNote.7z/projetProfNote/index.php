<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">

    <title>Connexion</title>
</head>

<body>
    
    <div id="sidebar">
        <div id="menu">
            <div class="case">
                <img src="img/user-profile.png" alt="pofile-picture"><br>
                <a href="">ADMIN</a><br>
            </div>
            <div class="case">
                <img src="img/user-profile.png" alt="pofile-picture"><br>
                <a href="">PROF</a><br>
            </div>
            <div class="case">
                <img src="img/user-profile.png" alt="pofile-picture"><br>
                <a href="">ELEVE</a>
            </div>
        </div>
    </div>

    <div id="corps">

        <div id="auth">
            <h1>AUTHENTIFICATION</h1>

            <form method="POST" action="index.php">
                <?php require 'connexion.php'; ?>
                <input type="text" name="txtlogin" placeholder="LOGIN..." required="required">
                <br>
                <input type="password" name="txtmdp" placeholder="MOT DE PASSE..." required="required">
                <br>
                <input type="submit" name="btnconnexion" value="Connexion">
            </form>

        </div>
        
    </div>

</body>
</html>