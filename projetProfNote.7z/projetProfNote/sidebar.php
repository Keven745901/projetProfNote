<div id="sidebar">
	<div id="menu">
		<a href="calendrier.php">Calendrier</a><br>
		<a href="mesevaluations.php">Evaluations</a><br>
		<a href="">Classes</a><br>
		<a href="">Messages</a><br>
		<a href="">Paramètres</a>
	</div>
</div>