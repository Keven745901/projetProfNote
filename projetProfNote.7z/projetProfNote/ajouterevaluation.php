<?php
session_start();
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/header_sidebar.css">
    <link rel="stylesheet" type="text/css" href="css/ajouterevaluation.css">
    <title>Création Evaluation</title>
</head>
<body>

<?php require "fonctions.php";
    if(!isset($_SESSION['professeur_id']))
    header('Location: index.php');
    $classe = reponseFiltree('Classe', 'professeur_id', $_SESSION['professeur_id'], 'contains');
?>

<?php include 'header.php'?>

    <div id="corps">
        <?php include 'sidebar.php'?>

        <div id="title_form">
            <h1>Nouvelle évaluation</h1>

            <form method="GET">
                <div class="infos_eval">
                    <label for="txtlibelle">Choisissez un nom : </label>
                    <input type="text" name="txtlibelle" required="required" placeholder="Libelle">
                </div>

                <div class="infos_eval">
                    <label for="txtdate">Date de l'évaluation : </label>
                    <input type="date" name="dtpdate" required="required" placeholder="Libelle">
                </div>

                <div class="infos_eval">
                    <label for="txtlibelle">Coefficient : </label>
                    <input type="text" name="txtcoef" required="required" placeholder="Coefficient">
                </div>

                <div class="infos_eval">
                    <label for="cboclasse">Choisissez une classe : </label>
                    <select name="cboclasse"> 
                        <?php foreach ($classe['rows'] as $item) {
                            echo "<option value='$item[classe_code]'>$item[libelle]</option><br>";
                        }?>
                    </select>
                </div>

                <input type="submit" name="btnvalider" value="Valider les informations">
                <?php require"ajouterevaluation_script.php"; ?>
            </form>

        </div>

    </div>

</body>
</html>