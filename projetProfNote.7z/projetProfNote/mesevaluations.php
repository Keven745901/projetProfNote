<?php
session_start();
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>Connexion</title>
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/header_sidebar.css">
    <link rel="stylesheet" type="text/css" href="css/mesevaluations.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
</head>

<body>

    <?php include 'header.php'?>

    <div id="corps">
        <?php include 'sidebar.php'?>

        <div id="evaluation_list">
            <div id="title_button">
                <h1>Mes évaluations</h1>
                <a href="ajouterevaluation.php"> <input id="addeval" type="button" value="Ajouter une évaluation"> </a>
            </div>

            <ul>
                <li id="infos">
                  <a>Nom</a>
                  <p>Date</p>
                  <a>Actions</a>  
                </li><hr>

                <?php
                    require "fonctions.php";
                    if(isset($_SESSION['professeur_id']))
                    {
                        $evals = reponseFiltree('Evaluation','professeur_id',$_SESSION['professeur_id'], 'contains');

                        if(isset($evals['rows'][0]['evaluation_id'])) {
                            foreach ($evals['rows'] as $item) {
                                echo "<li><a href='evaluation.php?eval=$item[evaluation_id]&libelle=$item[libelle]&coefficient=$item[coefficient]&classe=" .$item['classe_code']. "'>" .$item['libelle']. "</a><p>" .$item['evaluation_date']. "</p><a style='color:red' href='supprimereval.php?eval=$item[_id]'>Supprimer</a></li><hr>";
                            }
                        }
                        else
                            echo "Pas d'évaluations à afficher.";
                    }
                    else{
                        echo "Pas connecté.";
                    }
                ?>

            </ul>
        </div>

    </div>

</body>
</html>