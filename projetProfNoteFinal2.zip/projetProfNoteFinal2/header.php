<?php if(isset($_POST['btndeconnexion']))
{
    session_unset();
    session_destroy();
}?>

<header>
	<div id="identifier">

		<form method="POST" action="index.php">
			<input type="submit" name="btndeconnexion" value="Deconnexion">
		</form>
		
		<div id="name">
			<?php echo $_SESSION['prenom_professeur'] ?>
		</div>
		<div id="photo">
			<img src="img/user-profile.png" alt="pofile-picture">
		</div>
	</div>
</header>