<?php
session_start();
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/header_sidebar.css">
    <link rel="stylesheet" type="text/css" href="css/evaluation.css">
    <title>Notes</title>
</head>
<body>

<?php include 'header.php'?>

    <div id="corps">
        <?php include 'sidebar.php'?>

        <div id="informations">

            <?php
                require "fonctions.php";
                if(isset($_GET['eval']) || $_SESSION['notes']){
                
                    if(!isset($_GET['eval'])){
                        $_GET['eval'] = $_SESSION['eval'];
                        $_GET['libelle'] = $_SESSION['libelle'];
                        $_GET['coefficient'] = $_SESSION['coefficient'];
                    }
                    else{
                        $_SESSION['eval'] = $_GET['eval'];
                        $_SESSION['libelle'] = $_GET['libelle'];
                        $_SESSION['coefficient'] = $_GET['coefficient'];
                    }
                    $notes = reponseFiltree('Note','evaluation_id', $_GET['eval'], 'contains');
                    $_SESSION['notes']=$notes;

                    if(isset($_GET['btnsubmit'])){
                        majValeurNotes($_SESSION['notes']['rows']);
                    }

                    $somme = 0;
                    $nb = 0;
                    
                    echo "<div id='eval_infos'><h1>Evaluation : " .$_GET['libelle']. "</h1>";
                    echo "<p id='coef'>(coef.) " .$_GET['coefficient']. "</p></div>";
                    echo "<div id='column_name'><p>Nom</p><p>Note</p></div><hr>";
                    echo "<div id='content'><form method='GET' action='evaluation.php'><div id='eleves'>";
                    $notes = reponseFiltree('Note','evaluation_id', $_GET['eval'], 'contains');
                    $_SESSION['notes']=$notes;

                    $nb=0;
                    $tot=0;
                    $max=0;
                    $elevemax="";
                    $min=20;
                    $elevemin="";

                    foreach ($notes['rows'] as $item) {
                        if(!isset($item['valeur']))
                            $manote = "";
                        else
                            $manote = $item['valeur'];

                        echo "<div class='eleve'><p>" .$item['eleve_nom']. "</p><input type='text' value='" .$manote. "' name='" .$item['eleve_id'][0]. "'></div>";
                        if($manote!='')
                        {
                            $tot+=$manote;
                            $nb+=1;
                            if($max<$manote){
                                $max = $manote;
                                $elevemax = $item['eleve_nom'];
                            }
                            if($min>$manote){
                                $min = $manote;
                                $elevemin = $item['eleve_nom'];
                            }
                        }
                    }

                    echo "<input type='submit' name='btnsubmit' value='Valider et envoyer'>";
                    echo "</form>";

                    if($nb>0){
                        echo "</div><div id='calculs'><p>Moyenne : " .round($tot/$nb,2). "</p>";
                        echo "<p>Meilleure note : " .$elevemax. " " .$max. "</p>";
                        echo "<p>Moins bonne note : " .$elevemin. " " .$min. "</p></div></div>";
                    }
                    
                }
            ?>

        </div>

    </div>

</body>
</html>